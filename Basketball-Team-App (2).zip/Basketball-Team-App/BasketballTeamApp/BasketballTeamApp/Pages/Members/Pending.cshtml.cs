using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using BasketballTeamApp.Data;
using BasketballTeamApp.Data.Claims;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace BasketballTeamApp.Pages.Members
{
    public class PendingModel : PageModel
    {
        private readonly ApplicationDbContext _context;
        private readonly ILogger<PendingModel> _logger;
        
        public PendingModel(ApplicationDbContext context, ILogger<PendingModel> logger)
        {
            _context = context;
            _logger = logger;
        }

        public List<PendingMember> PendingMembers { get; set; }
        
        [BindProperty]
        public string UserId { get; set; }
        [BindProperty]
        public MemberStatus ChangeToStatus { get; set; }

        public class PendingMember
        {
            [Display(Name = "Action")]
            public string UserId { get; set; }
            [Display(Name = "Name")]
            public string FullName { get; set; }
        }
        
        public async Task OnGetAsync()
        {
            var memberClaims = _context.UserClaims
                .Where(c =>
                    c.ClaimType == AppClaims.MemberStatus
                    && c.ClaimValue == MemberStatus.Pending.ToString());
            var fullNames = _context
                .UserClaims
                .Where(c =>
                    c.ClaimType == AppClaims.FullName);
            PendingMembers = await memberClaims.Join(
                fullNames,
                mc => mc.UserId,
                fn => fn.UserId,
                (member, fullname) => new PendingMember
                {
                    UserId = member.UserId,
                    FullName = fullname.ClaimValue
                })
                .ToListAsync();
            // var games = await _context.Games
            //     .Select(c => new
            //     {
            //         UserId = c.UserId,
            //         Amount = c.Amount
            //     })
            //     .GroupBy(c => new
            //     {
            //         UserId = c.UserId
            //     })
            //     .Select(c => new
            //     {
            //         Id = c.Key.UserId,
            //         Amount = c.Sum(x => x.Amount)
            //     })
            //     .ToListAsync();

            // PendingMembers = members
            //     .Join(
            //         games,
            //         m => m.Id,
            //         g => g.Id,
            //         (member, total) =>    
            //             new MemberTotal
            //             {
            //                 UserId = member.Id,
            //                 Amount = total.Amount ?? 0,
            //                 FullName = member.FullName
            //             })
            //     .ToList();
        }

        public async Task<IActionResult> OnPostChangeStatusAsync(string id, MemberStatus action)
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            var claim = await _context.UserClaims
                .Where(c =>
                    c.ClaimType == AppClaims.MemberStatus
                    && c.UserId == id)
                .FirstOrDefaultAsync();

            claim.ClaimValue = action.ToString();
            
            // _context.Attach(claim).State = EntityState.Modified;

            try
            {
                _context.UserClaims.Update(claim);
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ClaimExists(claim.Id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return RedirectToPage("./Pending");
        }
        
        private bool ClaimExists(int id)
        {
            return _context.UserClaims.Any(e => e.Id == id);
        }
    }
}