using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using BasketballTeamApp.Data;
using BasketballTeamApp.Data.Claims;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace BasketballTeamApp.Pages.Members
{
    public class IndexModel : PageModel
    {
        private readonly ApplicationDbContext _context;
        private readonly ILogger<IndexModel> _logger;
        
        public IndexModel(ApplicationDbContext context, ILogger<IndexModel> logger)
        {
            _context = context;
            _logger = logger;
        }

        public List<MemberTotal> MemberTotals { get; set; }

        public class MemberTotal
        {
            [Display(Name = "MemberId")]
            public string UserId { get; set; }
            [Display(Name = "Member")]
            public string FullName { get; set; }
            [Display(Name = "Total Spend")]
            public double Amount { get; set; }
        }
        
        public async Task OnGetAsync()
        {
            var memberClaims = _context.UserClaims
                .Where(c =>
                    c.ClaimType == AppClaims.MemberStatus
                    && c.ClaimValue == MemberStatus.Approved.ToString());
            var fullNames = _context
                .UserClaims
                .Where(c =>
                    c.ClaimType == AppClaims.FullName);
            var members = await memberClaims.Join(
                fullNames,
                mc => mc.UserId,
                fn => fn.UserId,
                (member, fullname) => new
                {
                    Id = member.UserId,
                    FullName = fullname.ClaimValue
                })
                .ToListAsync();
            var games = await _context.Games
                .Select(c => new
                {
                    UserId = c.UserId,
                    Amount = c.Amount
                })
                .GroupBy(c => new
                {
                    UserId = c.UserId
                })
                .Select(c => new
                {
                    Id = c.Key.UserId,
                    Amount = c.Sum(x => x.Amount)
                })
                .ToListAsync();

            MemberTotals = members
                .Join(
                    games,
                    m => m.Id,
                    g => g.Id,
                    (member, total) =>
                        new MemberTotal
                        {
                            UserId = member.Id,
                            Amount = total.Amount ?? 0,
                            FullName = member.FullName
                        })
                .ToList();
            
            _logger.LogInformation("GroupBy {0}", members[0].FullName);
        }
    }
}