using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BasketballTeamApp.Pages.Members
{
    public class Approve : PageModel
    {
        public void OnGet()
        {
            
        }
    }
}