using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using BasketballTeamApp.Data;
using BasketballTeamApp.Data.Claims;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Identity;

namespace BasketballTeamApp.Pages.Games
{
    public class IndexModel : PageModel
    {
        private readonly ApplicationDbContext _context;

        public IndexModel(ApplicationDbContext context)
        {
            _context = context;
        }

        private IList<Game> Games { get;set; }
        private IList<IdentityUserClaim<string>> FullNames { get; set; }
        public IList<GameInfo> GamesInfos { get; set; }
        public ViewBy ViewBySetting { get; set; }

        public async Task OnGetAsync(ViewBy viewBy = ViewBy.Upcoming)
        {
            ViewBySetting = viewBy;
            
            switch (viewBy)
            {
                case ViewBy.Upcoming:
                    Games = await _context
                        .Games
                        .Where(cd => cd.Time > DateTime.Now)
                        .Include(cd => cd.User)
                        .ToListAsync();
                    break;
                case ViewBy.Past:
                    Games = await _context
                        .Games
                        .Where(cd => cd.Time < DateTime.Now)
                        .Include(cd => cd.User)
                        .ToListAsync();
                    break;
                default:
                    Games = await _context
                        .Games
                        .Include(cd => cd.User)
                        .ToListAsync();
                    break;
            }

            var notShoutedYet = Games
                .Where(cd => cd.UserId == null);
            var shouted = Games.Except(notShoutedYet);
            
            FullNames = await _context.UserClaims
                .Where(c => c.ClaimType == AppClaims.FullName)
                .ToListAsync();
            
            var shoutedWithNames = FullNames
                .Join(
                    shouted,
                    fn => fn.UserId,
                    cd => cd.UserId,
                    (names, coffeeDates) =>
                        new GameInfo
                        {
                            Id = coffeeDates.Id,
                            Time = coffeeDates.Time,
                            Venue = coffeeDates.Venue,
                            Amount = coffeeDates.Amount,
                            FullName = names.ClaimValue
                        }
                )
                .ToList();
            
            GamesInfos = shoutedWithNames
                .Concat(notShoutedYet.Select(n => new GameInfo(n)))
                .OrderBy(g => g.Time)
                .ToList();
        }

        public class GameInfo : Game
        {
            [DefaultValue("")]
            [Display(Name = "Paid by")]
            public string FullName { get; set; }
            
            public GameInfo() {}

            public GameInfo(Game g)
            {
                Id = g.Id;
                Venue = g.Venue;
                Amount = g.Amount;
                Time = g.Time;
            }
        }

        public enum ViewBy
        {
            All,
            Upcoming,
            Past
        }
    }
}
