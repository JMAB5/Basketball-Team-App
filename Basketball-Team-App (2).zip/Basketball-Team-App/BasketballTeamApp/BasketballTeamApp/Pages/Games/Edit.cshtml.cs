using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using BasketballTeamApp.Data;
using BasketballTeamApp.Data.Claims;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Logging;

namespace BasketballTeamApp.Pages.Games
{
    public class EditModel : PageModel
    {
        private readonly ApplicationDbContext _context;
        private readonly ILogger<EditModel> _logger;
        
        public EditModel(
            ApplicationDbContext context, 
            ILogger<EditModel> logger)
        {
            _context = context;
            _logger = logger;
        }

        [BindProperty]
        public Game Game { get; set; }
        public IEnumerable<IdentityUserClaim<string>> Members { get; private set; }

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            Game = await _context.Games.FirstOrDefaultAsync(g => g.Id == id);

            if (Game == null)
            {
                return NotFound();
            }

            var approvedMembers = await _context.UserClaims
                .Where(c =>
                    c.ClaimType == AppClaims.MemberStatus
                    && c.ClaimValue == MemberStatus.Approved.ToString())
                .Select(c => c.UserId)
                .ToListAsync();
            
            Members = await _context.UserClaims
                .Where(am => 
                    am.ClaimType == AppClaims.FullName
                    && approvedMembers.Contains(am.UserId))
                .ToListAsync();
            
            _logger.LogInformation("Input field for UserId: {0}", Members.First().UserId);
            
            return Page();
        }

        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            _logger.LogInformation("Update Game with UserId: {0}", Game.UserId);
            
            _context.Attach(Game).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!Games(Game.Id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return RedirectToPage("./Index");
        }

        private bool Games(int id)
        {
            return _context.Games.Any(e => e.Id == id);
        }
    }
}
