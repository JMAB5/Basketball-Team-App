using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using BasketballTeamApp.Data;
using BasketballTeamApp.Data.Claims;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;

namespace BasketballTeamApp.Pages.Games
{
    public class DeleteModel : PageModel
    {
        private readonly ApplicationDbContext _context;

        public DeleteModel(ApplicationDbContext context)
        {
            _context = context;
        }

        [BindProperty]
        public Game Game { get; set; }
        [Display(Name = "Paid by")]
        public string PaidBy { get; set; }

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            Game = await _context.Games
                .Include(g => g.User)
                .FirstOrDefaultAsync(g => g.Id == id);

            if (Game == null)
            {
                return NotFound();
            }
            
            if (Game.UserId != null && Game.User != null)
            {
                var shoutedBy = await _context.UserClaims
                    .Where(c =>
                        c.UserId == Game.UserId
                        && c.ClaimType == AppClaims.FullName)
                    .FirstOrDefaultAsync();

                PaidBy = shoutedBy.ClaimValue ?? string.Empty;
            }
            else
            {
                PaidBy = string.Empty;
            }
            
            return Page();
        }

        public async Task<IActionResult> OnPostAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            Game = await _context.Games.FindAsync(id);

            if (Game != null)
            {
                _context.Games.Remove(Game);
                await _context.SaveChangesAsync();
            }

            return RedirectToPage("./Index");
        }
    }
}
