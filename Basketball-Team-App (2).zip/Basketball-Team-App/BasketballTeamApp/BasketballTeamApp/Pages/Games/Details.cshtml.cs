using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using BasketballTeamApp.Data;
using BasketballTeamApp.Data.Claims;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace BasketballTeamApp.Pages.Games
{
    public class DetailsModel : PageModel
    {
        private readonly ApplicationDbContext _context;
        private readonly ILogger<DetailsModel> _logger;

        public DetailsModel(ApplicationDbContext context, ILogger<DetailsModel> logger)
        {
            _context = context;
            _logger = logger;
        }

        public Game Game { get; set; }
        [Display(Name = "Paid by")]
        public string PaidBy { get; set; }

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            Game = await _context.Games
                .Include(g => g.User)
                .FirstOrDefaultAsync(m => m.Id == id);
            
            if (Game == null)
            {
                return NotFound();
            }
            
            if (Game.UserId != null && Game.User != null)
            {
                var shoutedBy = await _context.UserClaims
                    .Where(c =>
                        c.UserId == Game.UserId
                        && c.ClaimType == AppClaims.FullName)
                    .FirstOrDefaultAsync();

                PaidBy = shoutedBy.ClaimValue ?? string.Empty;
            }
            else
            {
                PaidBy = string.Empty;
            }
            
            return Page();
        }
    }
}
