using System;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace BasketballTeamApp.Data
{
    public class Game
    {
        public int Id { get; set; }
        public string Venue { get; set; }
        public DateTime Time { get; set; }
        public double? Amount { get; set; }
        [Display(Name = "Paid by")]
        public string UserId { get; set; }
        
        // Navigation Properties
        public IdentityUser User { get; set; }
    }
    
    public class GameConfig : IEntityTypeConfiguration<Game>
    {
        public void Configure(EntityTypeBuilder<Game> builder)
        {
            // Primary Key
            builder.HasKey(u => u.Id);
            
            // Property config
            builder.Property(cd => cd.Venue).HasMaxLength(256);
            builder.Property(cd => cd.Time).IsRequired();
            builder.Property(cd => cd.Venue).IsRequired();
        }
    }
}