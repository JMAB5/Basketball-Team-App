namespace BasketballTeamApp.Data.Policies
{
    public static class AppPolicies
    {
        public const string ApprovedMember = "ApprovedMember";
    }
}