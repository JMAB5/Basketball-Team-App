namespace BasketballTeamApp.Data.Claims
{
    public static class AppClaims
    {
        public const string FullName = "FullName";
        public const string MemberStatus = "MemberStatus";
    }
}