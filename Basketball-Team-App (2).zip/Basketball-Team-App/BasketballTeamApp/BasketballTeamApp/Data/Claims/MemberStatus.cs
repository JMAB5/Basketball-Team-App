namespace BasketballTeamApp.Data.Claims
{
    public enum MemberStatus
    {
        Pending,
        Approved,
        Rejected
    }
}