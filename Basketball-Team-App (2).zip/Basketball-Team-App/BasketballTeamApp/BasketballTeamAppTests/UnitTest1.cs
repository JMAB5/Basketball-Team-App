using System;
using System.Threading.Tasks;
using BasketballTeamApp;
using BasketballTeamApp.Pages;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Logging;
using Moq;
using Xunit;

namespace BasketballTeamAppTests
{
    //Test Class
    public class UnitTest1
    {
        [Fact]
        public async Task IndexShouldNotRaiseException()
        {
            // Arrange
            var mock = new Mock<ILogger<IndexModel>>();
            var mocked = mock.Object;
            var page = new IndexModel(mocked);

            // Act and Assert - with fail it exception is raised
            page.OnGet();
        }
    }
}